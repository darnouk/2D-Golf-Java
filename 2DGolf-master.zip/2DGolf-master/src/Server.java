import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashSet;

public class Server {
	
	static String clientName1 = "";
	static String clientName2 = "";
	static String clientName3 = "";
	static String clientName4 = "";
	static String clientName5 = "";
	
	static int player1x = -100;
	static int player1y = -100;
	static int player2x = -100;
	static int player2y = -100;
	static int player3x = -100;
	static int player3y = -100;
	static int player4x = -100;
	static int player4y = -100;
	static int player5x = -100;
	static int player5y = -100;
	
	static int lastplayer1x = -1;
	static int lastplayer1y = -1;
	static int lastplayer2x = -1;
	static int lastplayer2y = -1;
	static int lastplayer3x = -1;
	static int lastplayer3y = -1;
	static int lastplayer4x = -1;
	static int lastplayer4y = -1;
	static int lastplayer5x = -1;
	static int lastplayer5y = -1;
   
	static int player1score = 0;
	static int player2score = 0;
	static int player3score = 0;
	static int player4score = 0;
	static int player5score = 0;
	
	static int counter = 0;

	static final int PORT = 7777;
	static HashSet<String> names = new HashSet<String>();
	static HashSet<PrintWriter> writers = new HashSet<PrintWriter>();
   
   
    
   public static void main(String[] args) throws Exception 
   {
      System.out.println("The server is running on port: "+PORT);
      ServerSocket listener = new ServerSocket(PORT);
      try
      {
         while (true) 
         {
            new Handler(listener.accept()).start();
         }
      } 
      finally 
      {
         listener.close();
      }
   }

private static class Handler extends Thread 
{
      private String name;
      private Socket socket;
      private BufferedReader in;
      private PrintWriter out;
      private String sender;
      private String input;

        public Handler(Socket socket) 
        {
            this.socket = socket;
        }
        
        public boolean checkIfUsed(String string)
        {
        	//If entered string does not equal any client names then return true else false
        	if(!(string.equalsIgnoreCase(clientName1)) && !(string.equalsIgnoreCase(clientName2)) && !(string.equalsIgnoreCase(clientName3)) && !(string.equalsIgnoreCase(clientName4)) && !(string.equalsIgnoreCase(clientName5)))
        		return true;
        	else
        		return false;	
        }

        public void run() 
        {
        try {
            	
                in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                out = new PrintWriter(socket.getOutputStream(),true);

                while (true)
                {
                    name = in.readLine();
                    if (name == null) 
                       {
                           return;
                       }
                    
                    if (name.startsWith("NAMESENT"))
                    {
                       name = name.substring(8);
                       name = name.replaceAll("\\s+","");
                       
                       synchronized (names) 
                       {
                           if (!names.contains(name)) 
                           {
                               System.out.println(name + " has joined the server.");
                               names.add(name);
                               
                               if (clientName1.isEmpty() && checkIfUsed(name))
                            	   clientName1 = name;
                               if (clientName2.isEmpty() && checkIfUsed(name))
                            	   clientName2 = name;
                               if (clientName3.isEmpty() && checkIfUsed(name))
                            	   clientName3 = name;
                               if (clientName4.isEmpty() && checkIfUsed(name))
                            	   clientName4 = name;
                               if (clientName5.isEmpty() && checkIfUsed(name))
                            	   clientName5 = name;
                               break;
                           }
                       }
                   }  
                }
                writers.add(out);
                
                while (true) 
                {
                	//From client info processing
                	input = in.readLine();
                	if (input == null)
                		input = "";
                    if (input.startsWith("SCORE"))
                    {
                    	sender = input.substring(5,25);
                    	sender = sender.replaceAll("\\s+","");
                    		
                    	if (sender.equalsIgnoreCase(clientName1))
                    		player1score = Integer.parseInt(input.substring(25));
                    	if (sender.equalsIgnoreCase(clientName2))
                    		player2score = Integer.parseInt(input.substring(25));
                    	if (sender.equalsIgnoreCase(clientName3))
                    		player3score = Integer.parseInt(input.substring(25));
                    	if (sender.equalsIgnoreCase(clientName4))
                    		player4score = Integer.parseInt(input.substring(25));
                    	if (sender.equalsIgnoreCase(clientName5))
                    		player5score = Integer.parseInt(input.substring(25));
                    }
                    if (input.startsWith("COORDX"))
                    {
                        sender = input.substring(6,26);
                        sender = sender.replaceAll("\\s+","");
                        	
                        if (sender.equalsIgnoreCase(clientName1))
                        	player1x = (int)Double.parseDouble(input.substring(26));
                        if (sender.equalsIgnoreCase(clientName2))
                        	player2x = (int)Double.parseDouble(input.substring(26));
                        if (sender.equalsIgnoreCase(clientName3))
                        	player3x = (int)Double.parseDouble(input.substring(26));
                        if (sender.equalsIgnoreCase(clientName4))
                        	player4x = (int)Double.parseDouble(input.substring(26));
                        if (sender.equalsIgnoreCase(clientName5))
                        	player5x = (int)Double.parseDouble(input.substring(26));

                    }
                    if (input.startsWith("COORDY"))
                    {
                        sender = input.substring(6,26);
                        sender = sender.replaceAll("\\s+","");
                        	
                        if (sender.equalsIgnoreCase(clientName1))
                        	player1y = (int)Double.parseDouble(input.substring(26));
                        if (sender.equalsIgnoreCase(clientName2))
                        	player2y = (int)Double.parseDouble(input.substring(26));
                        if (sender.equalsIgnoreCase(clientName3))
                        	player3y = (int)Double.parseDouble(input.substring(26));
                        if (sender.equalsIgnoreCase(clientName4))
                        	player4y = (int)Double.parseDouble(input.substring(26));
                        if (sender.equalsIgnoreCase(clientName5))
                        	player5y = (int)Double.parseDouble(input.substring(26));
                    }
                    
                    counter++;
                    if (counter % 3 == 0)
                    {

                    for (PrintWriter writer : writers)//Sends clients all x and y coords
                    {
                    	if (player1x != lastplayer1x)
                    	{	
                    		writer.println("P1COORDX" + player1x);
                    		lastplayer1x = player1x;
                    	}	
                    	if (player1y != lastplayer1y)
                    	{	
                    		writer.println("P1COORDY" + player1y);
                    		lastplayer1y = player1y;
                    	}	
                    	if (player2x != lastplayer2x)
                    	{
                    		writer.println("P2COORDX" + player2x);
                    		lastplayer2x = player2x;
                    	}	
                    	if (player2y != lastplayer2y)
                    	{	
                    		writer.println("P2COORDY" + player2y);
                    		lastplayer2y = player2y;
                    	}        		     
                    	if (player3x != lastplayer3x)
                    	{
                    		writer.println("P3COORDX" + player3x);
                    		lastplayer3x = player3x;
                    	}	
                    	if (player3y != lastplayer3y)
                    	{	
                    		writer.println("P3COORDY" + player3y);
                    		lastplayer3y = player3y;
                    	}         		     
                    	if (player4x != lastplayer4x)
                    	{
                    		writer.println("P4COORDX" + player4x);
                    		lastplayer4x = player4x;
                    	}	
                    	if (player4y != lastplayer4y)
                    	{	
                    		writer.println("P4COORDY" + player4y);
                    		lastplayer4y = player4y;
                    	}
                    	if (player5x != lastplayer5x)
                    	{
                    		writer.println("P5COORDX" + player5x);
                    		lastplayer5x = player5x;
                    	}	
                    	if (player5y != lastplayer5y)
                    	{	
                    		writer.println("P5COORDY" + player5y);
                    		lastplayer5y = player5y;
                    	}
                    	out.println("END");
                    	out.flush();
                    }	
                }
                }
            }
            catch (IOException e){}
        	finally
        	{
        		System.out.println(names.remove(name));
        		if (name.equals(clientName1))
            		clientName1 = "";
        		if (name.equals(clientName2))
        			clientName2 = "";
        		if (name.equals(clientName3))
        			clientName3 = "";
        		if (name.equals(clientName4))
        			clientName4 = "";
        		if (name.equals(clientName5))
        			clientName5 = "";
        		writers.remove(out);
        		try 
                {
                    socket.close();
                }
                catch (IOException e){}
        	}
        }
    }
}



/*

//for (PrintWriter writer : writers)//Sends clients all x and y coords
if (input.startsWith("REQUESTCOORDS"))
{
	//if (player1x != lastplayer1x)
	//{	//writer.println("P1COORDX" + player1x);
		out.println("P1COORDX" + player1x);
		//lastplayer1x = player1x;
	//}	
	//if (player1y != lastplayer1y)
	//{	
		out.println("P1COORDY" + player1y);
		//lastplayer1y = player1y;
	//}	
	//if (player2x != lastplayer2x)
	//{
		out.println("P2COORDX" + player2x);
		//lastplayer2x = player2x;
	//}	
	//if (player2y != lastplayer2y)
	//{	
		out.println("P2COORDY" + player2y);
		//lastplayer2y = player2y;
	//}        		     
	//if (player3x != lastplayer3x)
	//{
		out.println("P3COORDX" + player3x);
		//lastplayer3x = player3x;
	//}	
	//if (player3y != lastplayer3y)
	//{	
		out.println("P3COORDY" + player3y);
		//lastplayer3y = player3y;
	//}         		     
	//if (player4x != lastplayer4x)
	//{
		out.println("P4COORDX" + player4x);
		//lastplayer4x = player4x;
	//}	
	//if (player4y != lastplayer4y)
	//{	
		out.println("P4COORDY" + player4y);
		//lastplayer4y = player4y;
	//}
	//if (player5x != lastplayer5x)
	//{
		out.println("P5COORDX" + player5x);
		//lastplayer5x = player5x;
	//}	
	//if (player5y != lastplayer5y)
	//{	
		out.println("P5COORDY" + player5y);
		//lastplayer5y = player5y;
	//}
	out.println("END");
	out.flush();
}	
*/
