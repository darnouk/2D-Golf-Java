import java.awt.Color;
import java.awt.Graphics;

public class Ball 
{
	double XPos = 500;
	double YPos = 350;
	double FrictionX = .80;
	double FrictionY = .50;
	double VelocityX = 0;
	double VelocityY = 0;
	double AngleOfHit = 0;
	double HitPower = 0;
	int status = 0;
	int temp, temp2 = 0;
	boolean canMove = true;
	boolean over = true;
	boolean inHole = false;
	Graphics g;

	public Ball() {}
	
	public void update() 
	{
		updateBallPos();
	}
	
	public void updateBallPos()//Check if ball is out of bounds of map
	{
		
		if (VelocityX > 0)//If going right
		{
			VelocityX -= FrictionX;
			XPos += VelocityX;
		}	
		
		if (VelocityX < 0)//If going left
		{
			VelocityX += FrictionX;
			XPos += VelocityX;
		}	
		
		if (VelocityY > 0)//If going down
		{
			VelocityY -= FrictionY;
			YPos += VelocityY;
		}
		
		if (VelocityY < 0)//If going up
		{	
			VelocityY += FrictionY;
			YPos += VelocityY;
		}	
		
		
		//Max Velocities
		if (VelocityX > 40)//If going right
		{
			VelocityX = 40;
		}
		
		if (VelocityX < -40)//If going left
		{
				VelocityX = -40;
		}
		
		if (VelocityY > 40)//If going down
		{
			VelocityY = 40;
		}
			
		if (VelocityY < -40)//If going up
		{
			VelocityY = -40;
		}

		
		if (XPos >= 1000)
		{
			XPos = 1000;
			VelocityX = -VelocityX;
		}
		
		if (XPos <= 0)
		{
			XPos = 0;
			VelocityX = -VelocityX;
		}
		
		if (YPos >= 700)
		{
			YPos = 700;
			VelocityY = -VelocityY;
		}
		
		if (YPos <= 10)
		{
			YPos = 10;
			VelocityY = -VelocityY;
		}
		
	}
	
	public void drawBall(Graphics gBuffer)//For player ball drawing
	{	
		gBuffer.setColor(Color.white);
		gBuffer.fillOval((int)XPos-5,(int)YPos-5,10,10);
	}
	
	public void drawBall(Graphics gBuffer, int xx, int yy)//For enemy ball drawing
	{	
		gBuffer.setColor(Color.gray);
		gBuffer.fillOval((int)xx-5,(int)yy-5,10,10);
	}
	
	public void CalculateAngle()//Calculate the angle the ball would go if hit IN RADIANS
	{
		AngleOfHit = Math.atan2((GameLogic.hovery - YPos),(GameLogic.hoverx - XPos));
	}
	
	public void AngleToVelocities()//Returns value IN DEGREES, input must be RADIANS
	{
		VelocityX = HitPower * Math.cos(AngleOfHit);//Takes neccessary calculation to turn hit power and angle of hit
		VelocityY = HitPower * Math.sin(AngleOfHit);//to get the velocity it would get out of it
	}
	
	public double getXPos()
	{
		return XPos;//X position of the ball on the field
	}
	
	public double getYPos()
	{
		return YPos;//Y position of the ball on the field
	}
	
	public double getFrictionX()
	{
		return FrictionX;//Friction coefficient of the ball on the field
	}
	
	public double getFrictionY()
	{
		return FrictionY;//Friction coefficient of the ball on the field
	}
	
	public double getVelocityX()
	{
		return VelocityX;//X Velocity of the ball on the field
	}
	
	public double getVelocityY()
	{
		return VelocityY;//Y Velocity of the ball on the field
	}

}
