import java.io.*;
//import java.applet.AudioClip;
import java.awt.*;
import java.awt.event.*;

import javax.imageio.ImageIO;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
//import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
//import javax.sound.sampled.LineUnavailableException;
//import javax.sound.sampled.UnsupportedAudioFileException;


import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.UnsupportedAudioFileException;

import java.awt.image.BufferedImage;

public class MainLoop
{
	public static void main(String args[])
	{
		GameLogic tester = new GameLogic();
		
		tester.addWindowListener(new WindowAdapter()
		{public void windowClosing(WindowEvent e)
		{System.exit(0);}});
		tester.setSize(1000,700);
		tester.setVisible(true);
	}
}

@SuppressWarnings("serial")
class GameLogic extends Frame implements MouseListener,MouseMotionListener,KeyListener
{	

	static int clickx, clicky, hoverx, hovery;
	int timesrun;
	int timesrunn;
	int counter = 0;
	int clickCounter = 0;
	boolean focus = false;
	boolean first = true;
	boolean flipflop = false;
	boolean displayScoreboard = false;
	boolean singleplayer = false;
	boolean multiplayer = false;
	boolean help = false;
	static Ball ball = new Ball();
	Graphics gBuffer;
	Image virtualMem;
	BufferedImage TitleScreen;
	Rectangle wall, singlePlayer, multiPlayer, Help;
	AudioInputStream musicStream;
	Clip music;
	Client client = new Client();
   
	public GameLogic()
	{
		super("2D MiniGolf");
		addMouseListener(this);
		addMouseMotionListener(this);
		addKeyListener(this);
	    setFocusable(true);
        requestFocusInWindow();//Window must have focus and all necessary listeners before starting
  	}
	
	public void paint(Graphics g)
	{  
		setUp(g);//Only on first run
        if(!focus || clickCounter < 2)
        {
        	drawTitleScreen(gBuffer);
        	g.drawImage(virtualMem,0,0,this);
        }
        else
        {
        	updateGame();
        	runClient();
        	displayGame(gBuffer);//game display to gBuffer for doublebuffering
        	g.drawImage(virtualMem,0,0,this);
        	counter++;
        }
        delay(20);
        repaint();
	}
	
	public void setUp(Graphics g)
	{
		if (first)
		{
			wall = new Rectangle(-100,-100,0,0);
			singlePlayer = new Rectangle(290,260,400,75);//Singleplayer button
			multiPlayer = new Rectangle(290,358,400,75);//Multiplayer button
			Help = new Rectangle(290,456,400,75);//Help button
			virtualMem = createImage(1000,700);//Double buffering 
			gBuffer = virtualMem.getGraphics();
			try{TitleScreen = ImageIO.read(this.getClass().getResourceAsStream("TitleScreen.png"));} catch (IOException e) {}//Loads titlescreen			
			drawTitleScreen(gBuffer);
			g.drawImage(virtualMem,0,0,this);
			Player.newPlayer();
			//MapLoader.chooseMap();//choose map on first run
			MapLoader.changeMap("MapTest");
				/*
				try {
					musicStream = AudioSystem.getAudioInputStream(this.getClass().getResourceAsStream("Select.au"));
				} catch (UnsupportedAudioFileException e1) {
					e1.printStackTrace();
				} catch (IOException e1) {
					e1.printStackTrace();
				}
				try {
					music = AudioSystem.getClip();
				} catch (LineUnavailableException e) {
					e.printStackTrace();
				}
				try {
					music.open(musicStream);
				} catch (LineUnavailableException | IOException e) {
					e.printStackTrace();
				}*/
			first = false;
		}	
	}
	
	public void drawTitleScreen(Graphics gBuffer)
	{
		titleScreen(gBuffer);//title screen to gBuffer for doublebuffering
    	gBuffer.drawRect(290,260,400,75);//Singleplayer button
		gBuffer.drawRect(290,358,400,75);//Multiplayer button
		gBuffer.drawRect(290,456,400,75);//Help button
	}
	
	public void runClient()
	{
		if (multiplayer)
		{	
			try {
				client.run();
			} catch (IOException e) {}
		}
	}
	
	public double calculateLineDistance(double x1, double y1, double x2, double y2)
	{
		double distance = Math.hypot(x1-x2, y1-y2);
		return distance;
	}
	
	public void drawAimer(Graphics gBuffer)
	{
		double mouseBallDistance = calculateLineDistance(hoverx,hovery,ball.getXPos(),ball.getYPos());
		if (mouseBallDistance > 0)
			gBuffer.setColor(Color.green);
		if (mouseBallDistance > 250)
			gBuffer.setColor(Color.yellow);
		if (mouseBallDistance > 400)
			gBuffer.setColor(Color.red);
		
		for (int x = -2; x <= 2; x++)//Draws thick aimer line
			for (int y = -2; y <= 2; y++)
				gBuffer.drawLine(hoverx+x,hovery+y,(int)ball.getXPos()+x,(int)ball.getYPos()+y);
	}
	
	public void addWall(int r, int c)
	{
		int x = c * 20;//C is X
		int y = r * 20;//R is Y
		
		Rectangle wall1 = new Rectangle(x,y,20,20);
		wall.add(wall1);
	}
	
	public void displayGame(Graphics gBuffer)
	{	
		for (int r = 0; r < MapLoader.numRows; r++)//Draws the map based on the map loaded
			for (int c = 0; c < MapLoader.numCols; c++)
				switch(MapLoader.background[r].charAt(c))
					{
					    case '#' : MapLoader.drawGrass(gBuffer,r,c); break;
						case '=' : MapLoader.drawSideWall(gBuffer,r,c); addWall(r,c); break;
						case 'I' : MapLoader.drawVertWall(gBuffer,r,c); addWall(r,c); break;
						case '.' : MapLoader.drawSpace(gBuffer,r,c); addWall(r,c); break;
						case 'o' : MapLoader.drawCorner(gBuffer,r,c); addWall(r,c); break;
						case '*' : MapLoader.drawHole(gBuffer,r,c); break;
						case '|' : MapLoader.drawPole(gBuffer,r,c); break;
						default  : MapLoader.drawUnknown(gBuffer,r,c);
					}
		
        ball.drawBall(gBuffer,Client.player1x,Client.player1y);//Draws all other player balls
        ball.drawBall(gBuffer,Client.player2x,Client.player2y);
        ball.drawBall(gBuffer,Client.player3x,Client.player3y);
        ball.drawBall(gBuffer,Client.player4x,Client.player4y);
        ball.drawBall(gBuffer,Client.player5x,Client.player5y);

      
		if (!ball.inHole)//If ball is not in hole then draw it and aimer
		{	         
            drawAimer(gBuffer);
        	ball.drawBall(gBuffer);
		}
		
		if(displayScoreboard == true)//If scoreboard set to display then display
		{	
			//Scoreboard body
			gBuffer.setColor(new Color(255,255,255,200));//Transparent White
			gBuffer.fillRect(100,100,800,500);//Large outside rectangle
			
			//Scoreboard white highlights
			gBuffer.setColor(new Color(255,255,255,150));//More Transparent White
			gBuffer.fillRect(130,190,740,375);//Large inner rectangle
			gBuffer.fillRect(130,135,740,50);//Smaller Rectangle around title
			
			//Scoreboard outlines
			gBuffer.setColor(new Color(0,0,0,100));//Transparent Black
			gBuffer.drawRect(100,100,800,500);//Outline around the large outside rectangle
			gBuffer.drawRect(130,190,740,375);//Outline around the large inner rectangle
			gBuffer.drawRect(130,135,740,50);//Outline around the title box
			
			//Scoreboard player sections
			gBuffer.setColor(new Color(0,0,0,100));//Transparent Black
			gBuffer.drawRect(130,190,740,30);//Section for labels
			gBuffer.drawRect(130,220,740,69);//Section for first place
			gBuffer.drawRect(130,289,740,69);//Section for second place
			gBuffer.drawRect(130,358,740,69);//Section for thrid place
			gBuffer.drawRect(130,427,740,69);//Section for fourth place
			gBuffer.drawRect(130,496,740,69);//Section for last place
			gBuffer.drawLine(210,190,210,565);//Divides Place from Username
			gBuffer.drawLine(780,190,780,565);//Divides Username from Score
			
			
			//Scoreboard labels
			gBuffer.setColor(new Color(0,0,0,100));//Transparent Black
			gBuffer.setFont(new Font("Arial",Font.BOLD,70));
			gBuffer.drawString("1",150,281);
			gBuffer.drawString("2",150,350);
			gBuffer.drawString("3",150,419);
			gBuffer.drawString("4",150,488);
			gBuffer.drawString("5",150,557);
			gBuffer.setFont(new Font("Arial",Font.BOLD,18));
			gBuffer.drawString("Place",148,212);
			gBuffer.drawString("Username",425,212);
			gBuffer.drawString("Score",798,212);
			
			//Display scoreboard data
			gBuffer.setFont(new Font("Arial",Font.BOLD,50));
			gBuffer.drawString(Player.username1,220,278);
			gBuffer.drawString(Player.username2,220,347);
			gBuffer.drawString(Player.username3,220,416);
			gBuffer.drawString(Player.username4,220,485);
			gBuffer.drawString(Player.username5,220,554);
			
			//Scoreboard title text
			gBuffer.setFont(new Font("Arial",Font.BOLD,35));
			gBuffer.drawString("Scoreboard",415,173);
			
		}
	}
	
	public void checkCollisions()//If ball is colliding then do the needful
	{
		if (calculateLineDistance(MapLoader.holex,MapLoader.holey,(int)ball.getXPos(),(int)ball.getYPos()) <= 5 && ball.VelocityX < 10 && ball.VelocityY < 10)
		{	
			ball.inHole = true;//if the ball is close enough to hole and not going too fast then ball is in hole
		}
		/*
		if ((wall.contains(ball.getXPos(),ball.getYPos()))) //|| (wall.contains(ball.getXPos()+ball.VelocityX,ball.getYPos()+ball.VelocityY)))
		{	
			if (ball.getVelocityX() > 0)
				ball.VelocityX = -(ball.getVelocityX());
			
			if (ball.getVelocityX() < 0)
				ball.VelocityX = -(ball.getVelocityX());
			
			if (ball.getVelocityY() > 0)
				ball.VelocityY = -(ball.getVelocityY());
			
			if (ball.getVelocityY() < 0)
				ball.VelocityY = -(ball.getVelocityY());
		}
		*/
	}
	
	public void updateGame()//Update ball position based on speed and angle
	{
		if (!ball.inHole)
		{	
			ball.update();
			checkCollisions();
		}
	} 
	
	public void doAllBallMath(Ball ball)//Calculate starting ball speed
	{
		ball.HitPower = calculateLineDistance(hoverx,hovery,ball.getXPos(),ball.getYPos());
		if (ball.HitPower >= 500)
			ball.HitPower = 500;
		ball.HitPower /= 10;
		if (ball.HitPower <= 2)
			ball.HitPower = 2;
	}

	public void titleScreen(Graphics gBuffer)//Game title / pause screen goes here
	{     
			timesrunn++;
			gBuffer.setColor(Color.white);      
			gBuffer.fillRect(-10,-10,1210,1210);
			gBuffer.drawImage(TitleScreen,0,0,this);//Draws titlescreen image
			gBuffer.setColor(Color.black);
			gBuffer.setFont(new Font("Arial",Font.BOLD,36));
	}
   
	public void mouseMoved(MouseEvent e)//Anything that should execute if moused over goes in here
	{  
		hoverx = e.getX();
		hovery = e.getY();
	}
   
	public void mouseDragged(MouseEvent e)//Anything that should execute if either clicked or dragged should go in here
	{	
		focus = true;
		clickCounter++;
		
      if(!focus || clickCounter < 2){//Find out if game is multiplayer
		   if (singlePlayer.contains(e.getX(),e.getY()))
			   singleplayer = true;	
		   else singleplayer = false;
      }
      if(!focus || clickCounter < 2){//Find out if game is multiplayer
		   if (multiPlayer.contains(e.getX(),e.getY()))
			   multiplayer = true;	
		   else multiplayer = false;
     }
     if(!focus || clickCounter < 2){//Find out if game is multiplayer
		   if (Help.contains(e.getX(),e.getY()))
			   help = true;	
		   else help = false;
     }
		
		if ((int)ball.VelocityX == 0 && (int)ball.VelocityY == 0 )//If the ball is not moving then start next turn
		{	
			clickx = e.getX();
			clicky = e.getY();
			
			Player.clientScore++;
			ball.CalculateAngle();
			doAllBallMath(ball);
			ball.AngleToVelocities();
		}	
	}
	
	public void keyPressed(KeyEvent e)
	{
		switch (e.getKeyCode()) 
		{ 
	        case KeyEvent.VK_ESCAPE://Hit esc to toggle scoreboard
	        	if (flipflop == false)
	        	{
	        		flipflop = true;
	        		displayScoreboard = true;
	        	}
	        	else
	        	{
	        		flipflop = false;
	        		displayScoreboard = false;
	        	}
	            break;
	        case KeyEvent.VK_LEFT:
	        	ball.VelocityX += -5;
	        	break;
	        case KeyEvent.VK_RIGHT:
	        	ball.VelocityX += 5;
	        	break;
	        case KeyEvent.VK_UP:
	        	ball.VelocityY += -5;
	        	break;
	        case KeyEvent.VK_DOWN:
	        	ball.VelocityY += 5;
	        	break;
	        case KeyEvent.VK_SPACE:
	        	ball.VelocityX = 0;
	        	ball.VelocityY = 0;
	        	break;
		}
	}
	
	public static void delay(int n)
	{
		long startDelay = System.currentTimeMillis();
		long endDelay = 0;
		while (endDelay - startDelay < n)
			endDelay = System.currentTimeMillis();
	}
   
	public void update(Graphics g){paint(g);}
   
	public void mousePressed(MouseEvent e){mouseDragged(e);}
   
	public void mouseReleased(MouseEvent e){}
   
	public void mouseClicked(MouseEvent e){}
   
	public void mouseEntered(MouseEvent e){}
   
	public void mouseExited(MouseEvent e){}

	public void keyTyped(KeyEvent e){}

	public void keyReleased(KeyEvent e){}

}   