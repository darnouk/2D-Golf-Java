import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import javax.swing.JOptionPane;


public class Client 
{
	static Socket socket;
	static BufferedReader in;
	static PrintWriter out;
	static String line;
	static String serverAddress = "";
	static int counter;
   
	static int lastClientScore = -1;
	static int lastClientXPos = -1;
	static int lastClientYPos = -1;
   
	static int player1x = -100;
	static int player1y = -100;
	static int player2x = -100;
	static int player2y = -100;
	static int player3x = -100;	
	static int player3y = -100;
	static int player4x = -100;
	static int player4y = -100;
	static int player5x = -100;
	static int player5y = -100;

	public String getServerAddress() 
	{
		return JOptionPane.showInputDialog("Enter IP Address of the Server:");
	}

	public void run() throws IOException
	{

	   while (serverAddress.isEmpty())
	   {
		   serverAddress = getServerAddress();
	   
		   line = "";
   		   socket = new Socket(serverAddress, 7777);
   		   in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	   	   out = new PrintWriter(socket.getOutputStream(),true);
	   	   counter = 0;
	   }
	   line = "";//erase contents of line
	   out.println("NAMESENT"+Player.clientName);//Sent server client name
       
	   if (Player.clientScore != lastClientScore)//Only send if different
	   {
		   lastClientScore = Player.clientScore;
		   out.println("SCORE"+Player.clientName+Player.clientScore);
	   }
	   if ((int)GameLogic.ball.XPos != lastClientXPos)//Only send if different
	   {
		   lastClientXPos = (int)GameLogic.ball.XPos;
		   out.println("COORDX"+Player.clientName+GameLogic.ball.XPos);
	   }
	   if ((int)GameLogic.ball.YPos != lastClientYPos)//Only send if different
	   {
		   lastClientYPos = (int)GameLogic.ball.YPos;
		   out.println("COORDY"+Player.clientName+GameLogic.ball.YPos);
	   }
	   out.println("REQUESTCOORDS");
	   out.flush();
	   counter++;
	   while(true && (line = in.readLine())!= null && !(line.startsWith("END")))//Process remaining messages
	   {
			   //System.out.println(line);
		   if (line.startsWith("P1COORDX"))
		   {
			   player1x = Integer.parseInt(line.substring(8));
		   }
		   else if (line.startsWith("P1COORDY"))
		   {
			   player1y = Integer.parseInt(line.substring(8));
		   }
		   else if (line.startsWith("P2COORDX"))
		   {
			   player2x = Integer.parseInt(line.substring(8));
		   }
		   else if (line.startsWith("P2COORDY"))
		   {
			   player2y = Integer.parseInt(line.substring(8));
		   }
		   else if (line.startsWith("P3COORDX"))
		   {
			   player3x = Integer.parseInt(line.substring(8));
		   }
		   else if (line.startsWith("P3COORDY"))
		   {
			   player3y = Integer.parseInt(line.substring(8));
		   }
		   else if (line.startsWith("P4COORDX"))
		   {
			   player4x = Integer.parseInt(line.substring(8));
		   }
		   else if (line.startsWith("P4COORDY"))
		   {
			   player4y = Integer.parseInt(line.substring(8));
		   }
		   else if (line.startsWith("P5COORDX"))
		   {
			   player5x = Integer.parseInt(line.substring(8));
		   }
		   else if (line.startsWith("P5COORDY"))
		   {
			   player5y = Integer.parseInt(line.substring(8));
			   line = "";//erase contents of line
		   }   
	   }
	   //socket.close();
	}
}    