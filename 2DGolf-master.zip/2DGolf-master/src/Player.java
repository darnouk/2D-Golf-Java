import javax.swing.JOptionPane;

public class Player 
{
		static String clientName = "";
		static int clientScore = 0;
	
		static String username1 = "";
		static String username2 = "";
		static String username3 = "";
		static String username4 = "";
		static String username5 = "";
		
		static int score1 = 0;
		static int score2 = 0;
		static int score3 = 0;
		static int score4 = 0;
		static int score5 = 0;
		
		static int place1;
		static int place2;
		static int place3;
		static int place4;
		static int place5;
		
		static int turnNumber1;
		static int turnNumber2;
		static int turnNumber3;
		static int turnNumber4;
		static int turnNumber5;
		
		static boolean players1 = false;
		static boolean players2 = false;
		static boolean players3 = false;
		static boolean players4 = false;
		static boolean players5 = false;
		
		static int[] allScores;
		
	public static void newPlayer()//Makes a new player if given a username and join number
	{
		String user;
		user = JOptionPane.showInputDialog("Enter your name:");
		if (user.isEmpty())
			user = "Player 1";
		user += "                    ";//Force string to be at least 20 chars long	
		user = user.substring(0,20);//Force string to be max 20 chars long
		
		players1 = true;
		username1 = user;
		clientName = user;
	}
		
	public static void createScoresArray()//Creates an allScores array and sorts is highest to lowest
	{
		int[] scores = {score1,score2,score3,score4,score5};
		allScores = flipArray(smallestTolargestSort(scores));
	}
		
	public static void sortScores()//Have to sort the usernames into order based on scores
	{
		if (username1 != null)
		{
			
		}
		if (username2 != null)
		{

		}
		if (username3 != null)
		{

		}
		if (username4 != null)
		{

		}
		if (username5 != null)
		{

		}
	}
	
	public static int[] flipArray(int[] array)//Method to format arrays
	{
		for(int i = 0; i < array.length / 2; i++)
		{
			int temp = array[i];
			array[i] = array[array.length - i - 1];
			array[array.length - i - 1] = temp;
		}
		return array;
	}
	
	public static int[] smallestTolargestSort(int[] array)//Method to format arrays
	{
		int temp;
		for (int i = 0; i < array.length-1; i++)
		    {
		        if(array[i] > array[i+1])
		        {
		            temp=array[i];
		            array[i]=array[i+1];
		            array[i+1]=temp;
		            i=-1;
		        }
		    }
		return array;
	}
	
	
    
    
}





















/*
public class Player 
{
	static int totalPlayers = 1;
	String username;
	int score = 0;
	int place = 0;
	int turnNumber = 0;
	boolean playerConnected = true;
	boolean skipMe = false;
	
	
    public void playerUsername(String user)//Executed when the player joins the game
    {
    	username = user;//Stores username of new player
    	totalPlayers++;//Keeps track of current number of players
    	turnNumber = totalPlayers;//Turn number of player depends on when they joined
    }
    
    public void addToScore(int addtoscore)
    {
    	score += addtoscore;//Adds to player's score
    }
    
    public static int getTotalNumberOfPlayers()
    {
    	return totalPlayers;
    }

    public void playerLeave(String user)//Executed when the player leaves the game / times out
    {
    	playerConnected = false;
    	skipMe = true;
    	totalPlayers--;
    }
    
}*/



