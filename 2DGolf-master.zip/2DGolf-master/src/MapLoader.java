import java.io.*;
import java.awt.*;

import javax.swing.JOptionPane;


public class MapLoader 
{
	Graphics g;
	Graphics2D g2D = (Graphics2D) g;
	MapLoader outOfBounds = new MapLoader();
	static String mapSelected = "null";
	static int numRows = 35;//Maps must be 50x35 chars
	static int numCols = 50;
	static String background[];
	static String fileName = "null";
	static String newFileName = "";
	static int holex = -100;
	static int holey = -100;
	
	public static void changeMap(String fileName)
	{
		background = new String[numRows];
		try
		{
            BufferedReader inStream = new BufferedReader(new InputStreamReader(MainLoop.class.getClassLoader().getResourceAsStream(fileName+".dat")));
			String line;
			int row = 0;
			while((line = inStream.readLine()) != null)
			{
				background[row] = line;
				row++;
			}
			inStream.close();
		}
		catch (IOException e)
		{
			System.out.println("There were problems with the code as stated below\n");
			System.out.println(e.getMessage());
		}
		mapSelected = fileName;
	}
	
	public static void chooseMap()//Level loader
	{	
		newFileName = JOptionPane.showInputDialog("Enter level name: MapTest, Blank or Blank2");
		if (newFileName.isEmpty())
			fileName = "MapTest";
		else
			fileName = newFileName;
		background = new String[numRows];
		try
		{
            BufferedReader inStream = new BufferedReader(new InputStreamReader(MainLoop.class.getClassLoader().getResourceAsStream(fileName+".dat")));
			String line;
			int row = 0;
			while((line = inStream.readLine()) != null)
			{
				background[row] = line;
				row++;
			}
			inStream.close();
		}
		catch (IOException e)
		{
			System.out.println("There were problems with the code as stated below\n");
			System.out.println(e.getMessage());
		}
		mapSelected = fileName;
	}

	public static int convert(int q)
	{
		return q * 20;
	}

	public static void drawSpace (Graphics g, int r, int c)
	{
		int x = convert(c);
		int y = convert(r);
		g.setColor(Color.black);
		g.fillRect(x,y,20,20);
	}

	public static void drawSideWall (Graphics g, int r, int c)
	{
		int x = convert(c);
		int y = convert(r);
		g.setColor(new Color(165,42,42));//Red color
		g.fillRect(x,y,20,20);
		g.setColor(Color.black);
		g.fillOval(x+5,y+5,10,10);
		g.setColor(Color.white);
		for(int j = 0; j<=16; j+=4)
		{
			g.drawLine(x+j,y+2,x+j,y+2);
			g.drawLine(x+j,y+17,x+j,y+17);
		}
		
	}
	
	public static void drawVertWall (Graphics g, int r, int c)
	{
		int x = convert(c);
		int y = convert(r);
		g.setColor(new Color(165,42,42));//Red color
		g.fillRect(x,y,20,20);
		g.setColor(Color.black);
		g.fillOval(x+5,y+5,10,10);
		g.setColor(Color.white);
		for(int j = 0; j<=16; j+=4)
		{
			g.drawLine(x+2,y+j,x+2,y+j);
			g.drawLine(x+17,y+j,x+17,y+j);
		}
	}

	public static void drawGrass (Graphics g, int r, int c)
	{
		int x = convert(c);
		int y = convert(r);
		g.setColor(new Color(11,84,0));//Dark Green
		g.fillRect(x,y,20,20);
	}

	public static void drawCorner(Graphics g, int r, int c)
	{
		int x = convert(c);
		int y = convert(r);
		g.setColor(new Color(165,42,42));
		g.fillRect(x,y,20,20);
		g.setColor(Color.black);
		g.fillOval(x+5,y+5,10,10);
		g.setColor(Color.white);
		for(int j = 0; j<=16; j+=4)
		{
			g.drawLine(x+2,y+j,x+2,y+j);
			g.drawLine(x+17,y+j,x+17,y+j);
		}
		for(int j = 0; j<=16; j+=4)
		{
			g.drawLine(x+j,y+2,x+j,y+2);
			g.drawLine(x+j,y+17,x+j,y+17);
		}
	}

	public static void drawHole (Graphics g, int r, int c)
	{
		int x = convert(c);
		int y = convert(r);
		g.setColor(new Color(11,84,0));//Dark Green
		g.fillRect(x,y,20,20);
		g.setColor(Color.black);
		g.fillOval(x+3,y+3,12,12);
		g.fillRect(x+8,y-5,4,15);
		holex = x+10;
		holey = y+10;
	}

	public static void drawPole (Graphics g, int r, int c)
	{
		int x = convert(c);
		int y = convert(r);
		g.setColor(new Color(11,84,0));//Dark Green
		g.fillRect(x,y,20,20);
		g.setColor(Color.black);
		g.fillRect(x+8,y-2,4,20);
		g.setColor(Color.white);
		g.fillRect(x+12,y-2,8,10);
	}

	public static void drawUnknown (Graphics g, int r, int c)
	{
		int x = convert(c);
		int y = convert(r);
		g.setColor(Color.pink);
		g.fillRect(x,y,20,20);
		g.setColor(Color.black);
		g.drawOval(x,y,19,19);
		g.drawString("?",x+6,y+15);
	}

}